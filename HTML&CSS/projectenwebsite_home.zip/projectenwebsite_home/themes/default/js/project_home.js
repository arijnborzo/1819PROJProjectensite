function showDiscussions(proj_id){
	var html_id = "proj_discussions_"+proj_id;
	if($(html_id).css("display") == "block"){
		$(html_id).css("display","none");
	}else{
		$(html_id).css("display","block");
	}
}

function startDiscussion(proj_id){
	var html_id = "#proj_new_discussion_"+proj_id;
	var button_id = "#startDiscussionButton_"+proj_id;
	if($(html_id).css("display") == "block"){
		$(html_id).css("display","none");
		$(button_id).text("start Discussion");
	}else{
		$(html_id).css("display","block");
		$(button_id).text("Cancel");
	}
}